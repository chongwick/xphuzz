#!/bin/bash

# Usage: ./move_rb_files.sh <source_directory> <destination_directory>

if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_directory> <destination_directory>"
    echo "Example: $0 ./project ./all_ruby_files"
    exit 1
fi

SOURCE_DIR="$1"
DEST_DIR="$2"

# Check if source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Source directory '$SOURCE_DIR' does not exist."
    exit 1
fi

# Create destination directory if it doesn't exist
mkdir -p "$DEST_DIR"

# Find and move all .rb files recursively
echo "Moving all .rb files from '$SOURCE_DIR' to '$DEST_DIR'..."

# Option 1: Using find + mv (recommended - handles filenames with spaces/special chars safely)
find "$SOURCE_DIR" -type f -name "*.rb" -print0 | while IFS= read -r -d '' file; do
    # Get the basename (filename only)
    filename=$(basename "$file")
    
    # Move the file (will overwrite if same name exists in destination)
    mv "$file" "$DEST_DIR/$filename"
    echo "Moved: $file → $DEST_DIR/$filename"
done

echo "Done! All .rb files have been moved."
