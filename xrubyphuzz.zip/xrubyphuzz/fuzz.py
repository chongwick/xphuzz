from openai import OpenAI
import os
import random

input_corpus = [os.path.join("corpus",i) for i in os.listdir("corpus")]
bug_corpus = [os.path.join("super_corpus",i) for i in os.listdir("super_corpus")]

client = OpenAI(
        base_url="http://localhost:8201/v1",
        api_key = "sk-no-key-required"
        )

def build_query():
    role = "You are a fuzzer for the Ruby interpreter. Your goal is to uncover crashing cases. Here are some values to consider using: 0, 1, -1, 1000000000000000000000000, -10000000000000000000000. Respond only with ```<code>```"
    context = [{'role': 'system', 'content': role}]

    prompt = "# Goal: Make a high-quality fuzzing seed using structures from the following seeds.\n Avoid using relative dependencies."
    for i in range(2):
        with open(random.choice(input_corpus),"r") as f:
            text = f.read()
        prompt += "\n## Seed {idx}: \n ```\n{t}\n```".format(idx=i,t=text)

    with open(random.choice(bug_corpus),"r") as f:
        text = f.read()
    prompt += "\n## HISTORICAL CRASHING BUG : \n ```\n{t}\n```".format(t=text)

    print(prompt);quit()
    context.append({"role":"user","content":prompt})

    return context

def query_llm(context) -> str:
    global client
    response = client.chat.completions.create(
            model="local-model",
            messages=context,
            temperature=0.7,
            max_tokens=512,
            stream=False,
            )
    return response.choices[0].message.content


context = build_query()
print(query_llm(context))
